## Introduction
Welcome! In this workshop, you will learn how to create a simple 2D platformer level in Godot 4.6. By the end, you will have a playable character capable of moving and jumping within a custom built level.

**GitHub Link:**
[Workshop Assets](https://github.com/MRU-GDDC/Godot_Workshop_Febuary_2026)
**Instructions**
[Instructions](https://drive.google.com/file/d/1e_IbfbOcGtlGwrE84jepOZMwcGFHYWRH/view?usp=sharing)
